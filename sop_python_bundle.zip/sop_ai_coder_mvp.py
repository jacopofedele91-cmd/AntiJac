
"""
SOP AI‑Coder‑Ready (Python) – App Lines Specialist Incontinenza (MVP)
--------------------------------------------------------------------
Scopo: fornire una SOP *eseguibile/leggibile dalla macchina*, espressa in Python,
che definisce modelli dati, regole deterministiche, endpoint e policy per generare
un MVP con 4 moduli: Coach, Oggi mi sento, Giornate speciali, Prodotto per te.

Nota: questo file funge da *sorgente vivente* della specifica. Può essere letto
sia dagli umani che da tool di codegen (es. Antigravity) per bootstrap backend.

Stack target (suggerito, ma non vincolante): FastAPI + Pydantic (backend), Flutter (mobile).

DISCLAIMER: L'app non è un dispositivo medico. In caso di sintomi insoliti o dolore,
contattare il medico. GDPR by design: consensi granulari, export/delete, privacy by default.
"""

from typing import List, Literal, Optional
from dataclasses import dataclass

# =============================
# 1) Feature flags & Config
# =============================

@dataclass
class FeatureFlags:
    community: bool = False  # disabilitata in MVP
    coupons: bool = False

@dataclass
class NotificationPolicy:
    max_per_day: int = 3
    min_interval_min: int = 90
    quiet_hours_start: str = "22:00"
    quiet_hours_end: str = "07:00"
    snooze_hours: int = 24

FEATURE_FLAGS = FeatureFlags()
NOTIFICATION_POLICY = NotificationPolicy()

PRIVACY_RETENTION = {
    "retention_months_default": 18,
    "retention_options": [3, 6, 18],
    "delete": {"soft_immediate": True, "hard_days": 30},
}

ANALYTICS_EVENTS = [
    {"name": "questionnaire.submitted", "props": ["has_night", "freq", "volume"]},
    {"name": "recommendation.viewed", "props": ["level", "confidence"]},
    {"name": "ops.created", "props": ["trigger", "volume", "context", "offline"]},
    {"name": "coach.session.start", "props": ["level"]},
    {"name": "coach.session.complete", "props": ["level", "duration_sec"]},
    {"name": "specialday.checklist.open", "props": ["type"]},
    {"name": "specialday.checklist.complete", "props": ["type"]},
    {"name": "notification.tap", "props": ["key"]},
    {"name": "consent.changed", "props": ["consent", "value"]},
]

NOTIFICATION_STRINGS = {
    "coach.start": "È il momento di una mini‑routine 💪",
    "specialday.ready": "Checklist pronta per te",
    "pitstop.reminder": "Prenditi un minuto per te",
    "hydrate.sip": "Un piccolo sorso può bastare",
    "generic.ok": "Promemoria giornaliero attivo ✅",
}

# ===================================
# 2) Modelli dati (Pydantic opzionale)
# ===================================
try:
    from pydantic import BaseModel, Field

    class QuestionnaireAnswers(BaseModel):
        D1_outdoor: Optional[Literal['high','medium','low']] = None
        D2_freq: Literal['rare','sometimes','often']
        D3_dayparts: Optional[List[Literal['morning','afternoon','evening','night']]] = None
        D4_triggers: Optional[List[Literal['effort','cough_laugh','urgency','sport','unknown']]] = None
        D5_volume: Literal['micro','small','medium']
        D6_night: Optional[Literal['never','sometimes','often']] = 'never'
        D7_activity: Optional[Literal['high','medium','low']] = None
        D8_discretion: Optional[Literal['very','balanced','capacity']] = None
        D9_skin: Optional[Literal['yes','sometimes','no']] = None
        D10_preference: Optional[Literal['thin','medium','high','na']] = None

    class Recommendation(BaseModel):
        level: Literal['L1','L2','L3','L4','L5']
        product_id: Optional[str] = None
        confidence: float = Field(ge=0, le=1, default=0.7)
        reasons: List[str] = []

    class OpsLog(BaseModel):
        ts: str
        trigger: Literal['urgency','effort','sport','unknown']
        volume: Literal['micro','small','medium']
        context: Optional[Literal['home','work','outdoor','car','sleep']] = None
        note: Optional[str] = None

    PydanticEnabled = True
except Exception:
    # Fallback minimale senza Pydantic per la sola lettura della SOP
    PydanticEnabled = False

# =====================================
# 3) Motore a regole – deterministico
# =====================================

MAP_D2 = { 'rare': 1, 'sometimes': 2, 'often': 3 }
MAP_D5 = { 'micro': 1, 'small': 2, 'medium': 4 }
MAP_TRIG = { 'effort': 1, 'cough_laugh': 1, 'urgency': 3, 'sport': 2, 'unknown': 2 }
MAP_D6 = { 'never': 0, 'sometimes': 1, 'often': 4 }

ORD_LEVELS = ['L1','L2','L3','L4','L5']

def score_from_answers(a: dict) -> int:
    score = 0
    score += MAP_D2.get(a.get('D2_freq'), 0)
    score += MAP_D5.get(a.get('D5_volume'), 0)
    triggers = a.get('D4_triggers') or []
    if isinstance(triggers, list) and triggers:
        trig_max = max(MAP_TRIG.get(t, 0) for t in triggers)
        score += trig_max
    score += MAP_D6.get(a.get('D6_night','never'), 0)
    if a.get('D1_outdoor') == 'high':
        score += 1
    if a.get('D7_activity') == 'high':
        score += 1
    return score

def level_from_score(score: int) -> str:
    if score <= 3: return 'L1'
    if score <= 6: return 'L2'
    if score <= 10: return 'L3'
    if score <= 14: return 'L4'
    return 'L5'

def apply_overrides(ans: dict, level: str) -> str:
    def min_level(current: str, minimum: str) -> str:
        return ORD_LEVELS[max(ORD_LEVELS.index(current), ORD_LEVELS.index(minimum))]

    # Override A: notturno spesso ⇒ minimo L4
    if ans.get('D6_night') == 'often':
        level = min_level(level, 'L4')

    # Override B: urgenza + small ⇒ minimo L3
    if isinstance(ans.get('D4_triggers'), list) and 'urgency' in ans['D4_triggers'] and ans.get('D5_volume') == 'small':
        level = min_level(level, 'L3')

    # Soft preference (non cambia livello, ma futura variante di prodotto)
    # D8=very (discrezione) e livello L2–L3 ⇒ proporre versione sottile (gestito in mapping prodotto)
    # D9 in {yes,sometimes} ⇒ proporre variante delicata
    return level

# =====================================
# 4) API Stub (FastAPI opzionale)
# =====================================
try:
    from fastapi import FastAPI, HTTPException
    from fastapi.responses import JSONResponse

    app = FastAPI(title="IncontApp API", version="0.1.0")

    @app.post('/questionnaire/submit')
    def questionnaire_submit(body: dict):
        # Valida campi minimi
        if not body.get('D2_freq') or not body.get('D5_volume'):
            raise HTTPException(status_code=400, detail={"error":"Q001","message":"Risposte mancanti/invalidi"})
        score = score_from_answers(body)
        level = apply_overrides(body, level_from_score(score))
        reasons = [f"frequenza={body.get('D2_freq')}", f"volume={body.get('D5_volume')}"]
        if body.get('D6_night') and body.get('D6_night') != 'never':
            reasons.append(f"notte={body.get('D6_night')}")
        if body.get('D4_triggers'):
            reasons.append(f"trigger={'+'.join(body['D4_triggers'])}")
        return JSONResponse({"level": level, "product_id": None, "confidence": 0.72, "reasons": reasons})

    @app.post('/ops')
    def log_ops(body: dict):
        # Stub: accetta qualunque log valido
        if not body.get('ts') or not body.get('trigger') or not body.get('volume'):
            raise HTTPException(status_code=400, detail={"error":"Q001","message":"Campi obbligatori mancanti"})
        return JSONResponse({"ok": True})

    @app.post('/recommendation/refresh')
    def recommendation_refresh():
        # Stub: simulazione aggiornamento
        return JSONResponse({"level": "L3", "product_id": None, "confidence": 0.75, "reasons": ["aggiornamento basato su Ops"]})

    @app.get('/user/export')
    def user_export():
        return JSONResponse({"user": {"id": "demo", "lang": "it"}, "data": {}})

    @app.delete('/user/delete')
    def user_delete():
        return JSONResponse(status_code=202, content={"ok": True})

    FastAPIEnabled = True
except Exception:
    # Nessuna dipendenza: la SOP resta valida come specifica, senza server attivo
    FastAPIEnabled = False

# =====================================
# 5) Acceptance Criteria (gherkin-like)
# =====================================
ACCEPTANCE = {
    "questionario": [
        "Given D2=sometimes, D5=small, D4=effort, D6=never -> When submit -> Then level=L2 +/- and confidence > 0.6",
        "Given D6=often with base < L4 -> Then output level >= L4",
    ],
    "momenti_ops": [
        "Given valid ts/trigger/volume -> When POST /ops -> Then 200 OK",
    ],
    "coach": [
        "6 micro-routine disponibili; progressione dopo >=80% aderenza 7d (logica lato app)",
    ],
    "giornate_speciali": [
        "Checklist Sport/Viaggio attivabili; notifiche rispettano quiet hours",
    ],
}

# =====================================
# 6) Helper CLI (solo documentativo)
# =====================================
if __name__ == '__main__':
    print("SOP Python caricata. Stato componenti:")
    print(f" - Pydantic: {'ON' if PydanticEnabled else 'OFF'}")
    print(f" - FastAPI:  {'ON' if FastAPIEnabled else 'OFF'}")
    print("
Esempio scoring rapido:")
    example = {"D2_freq":"sometimes","D5_volume":"small","D4_triggers":["effort"],"D6_night":"never"}
    s = score_from_answers(example)
    lvl = apply_overrides(example, level_from_score(s))
    print({"score": s, "level": lvl})
