
#!/usr/bin/env bash
set -euo pipefail

# Create venv if not exists
if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate

python -m pip install --upgrade pip
pip install -r requirements.txt

# Run FastAPI app
exec uvicorn sop_ai_coder_mvp:app --host 0.0.0.0 --port 8000 --reload
