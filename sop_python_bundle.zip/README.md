
# SOP Python – Avvio rapido

Questa cartella contiene la SOP eseguibile in **Python** per l'MVP dell'app Lines Specialist.

## Requisiti
- Python 3.10+
- (Opzionale) accesso internet per installare i pacchetti

## Avvio su macOS/Linux
```bash
cd sop_python
./run.sh
```
Server attivo su: http://127.0.0.1:8000

## Avvio su Windows
```bat
cd sop_python
run.bat
```

## Endpoint principali
- `POST /questionnaire/submit`
- `POST /ops`
- `POST /recommendation/refresh`
- `GET /user/export`
- `DELETE /user/delete`

> Generato il 2026-03-09 20:52:09.
