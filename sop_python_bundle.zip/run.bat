
@echo off
setlocal ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION

if not exist .venv (
    py -3 -m venv .venv
)

call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt

uvicorn sop_ai_coder_mvp:app --host 0.0.0.0 --port 8000 --reload
